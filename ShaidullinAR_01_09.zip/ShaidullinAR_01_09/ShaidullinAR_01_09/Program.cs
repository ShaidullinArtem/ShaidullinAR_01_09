﻿using ShaidullinAR_01_09.Types;
using System.Threading.Channels;


Athlete createAthlete() {

    try {
        Console.WriteLine("Введите вес:");
        double weight = double.Parse(Console.ReadLine());

        Console.WriteLine("Введите рост:");
        double height = double.Parse(Console.ReadLine());

        Console.WriteLine("Введите возраст:");
        int age = int.Parse(Console.ReadLine());

        return new Athlete(weight, height, age);
    }
    catch {
        throw new Exception("Данные введены неверно!");
    }
}

Target createTarget() {
    try
    {
        Console.WriteLine("Введите вес:");
        double weight = double.Parse(Console.ReadLine());

        Console.WriteLine("Введите рост:");
        double height = double.Parse(Console.ReadLine());

        Console.WriteLine("Введите возраст:");
        int age = int.Parse(Console.ReadLine());

        Console.WriteLine("Введите тип тела (fit / fat)");
        string bodyType = Console.ReadLine();

        return new Target(weight, height, age, bodyType == "fit" ? EnumBodyType.Fit : EnumBodyType.Fat);
    }
    catch
    {
        throw new Exception("Данные введены неверно!");
    }
}


while (true) {
    Console.WriteLine("1. Создать спортсмена\n2. Создать цель\n3. Выход");
    Console.WriteLine("Выбериет действие:");
    string choise = Console.ReadLine();
    switch (choise) {
        case "1":
            Athlete athlete = createAthlete();
            Console.WriteLine(athlete);
            break;
        case "2":
            Target target = createTarget();
            Console.WriteLine(target);
            break;
        case "3":
            Environment.Exit(0);
            break;
        default:
            Console.WriteLine("Такого действия нет");
            break;
    }
}
