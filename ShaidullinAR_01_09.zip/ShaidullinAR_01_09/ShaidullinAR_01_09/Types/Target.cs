﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShaidullinAR_01_09.Types
{
    /* Reflects the athlete's physique **/
    public enum EnumBodyType {
        Fit,
        Fat
    }

    public class Target : Athlete
    {
        public EnumBodyType P { get; set; }

        public Target()
        {
            
        }

        public Target(double weight, double height, int age, EnumBodyType p) : base(weight, height, age)
        {
            P = p;
            Weight = weight;
            Height = height;
            Age = age;
        }

        public override double Q()
        {
            switch (P) {
                case EnumBodyType.Fit:
                    return base.Q() - 500;
                case EnumBodyType.Fat:
                    return base.Q() + 900;
                default:
                    throw new ArgumentOutOfRangeException(nameof(P), P, null);
            }
        }

        public override string ToString()
        {
            return base.ToString() + $"P: {Q()}";
        }
    }
}
