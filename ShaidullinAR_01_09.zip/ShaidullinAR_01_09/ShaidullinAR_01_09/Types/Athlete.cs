﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShaidullinAR_01_09.Types
{
    public class Athlete
    {
        public double Weight { get; set; }
        public double Height { get; set; }
        public int Age { get; set; }

        public Athlete()
        {
            
        }

        public Athlete(double weight, double height, int age) 
        {
            Weight = weight;
            Height = height;
            Age = age;  
        }

        public virtual double Q() {
            return (Height * 1.8) - (Age * 4.7) + (Weight * 9.6) + 1255;
        }

        public override string ToString()
        {
            return $"Рост: {Height}\nВозраст: {Age}\nВес тела: {Weight}\nQ: {Q()}\n";
        }
    }
}
